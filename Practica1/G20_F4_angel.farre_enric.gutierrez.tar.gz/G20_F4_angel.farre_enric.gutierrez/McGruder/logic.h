/*Angel Farre - angel.farre & Enric Gutierrez - enric.gutierrez*/

#ifndef _LOGIC_H_
#define _LOGIC_H_

void checkFiles();

void readConfigFile(char * fileName);

#endif